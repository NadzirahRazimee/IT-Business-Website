
// ===== SERVER.JS (Enhanced Backend) =====
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public'));

// Database setup
const db = new sqlite3.Database('./website_v3.db', (err) => {
    if (err) {
        console.error('Error opening database:', err);
    } else {
        console.log('Connected to SQLite database V3');
        initializeDatabase();
    }
});

function initializeDatabase() {
    // Contact messages table
    db.run(`
        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            subject TEXT,
            message TEXT NOT NULL,
            status TEXT DEFAULT 'unread',
            priority INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // Enhanced portfolio table
    db.run(`
        CREATE TABLE IF NOT EXISTS portfolio (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            image_url TEXT,
            project_url TEXT,
            github_url TEXT,
            category TEXT,
            tech_stack TEXT,
            featured BOOLEAN DEFAULT 0,
            views INTEGER DEFAULT 0,
            likes INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // Newsletter subscribers with preferences
    db.run(`
        CREATE TABLE IF NOT EXISTS subscribers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            name TEXT,
            preferences TEXT DEFAULT 'all',
            active BOOLEAN DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // Blog posts table
    db.run(`
        CREATE TABLE IF NOT EXISTS blog_posts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            excerpt TEXT,
            image_url TEXT,
            category TEXT,
            tags TEXT,
            published BOOLEAN DEFAULT 0,
            views INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // Analytics table
    db.run(`
        CREATE TABLE IF NOT EXISTS analytics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            event_data TEXT,
            ip_address TEXT,
            user_agent TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // Insert enhanced sample data
    const enhancedProjects = [
        {
            title: "NeoSync Dashboard",
            description: "Advanced analytics platform with real-time data visualization and AI insights",
            image_url: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop",
            category: "Web Application",
            tech_stack: "React, Node.js, D3.js, MongoDB",
            featured: 1,
            views: 1250,
            likes: 89
        },
        {
            title: "Aurora Mobile Suite",
            description: "Cross-platform mobile application with biometric authentication and offline sync",
            image_url: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=600&h=400&fit=crop",
            category: "Mobile App",
            tech_stack: "React Native, Firebase, TypeScript",
            featured: 1,
            views: 980,
            likes: 67
        },
        {
            title: "Quantum E-commerce",
            description: "Next-generation shopping platform with AR try-on and personalized recommendations",
            image_url: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&h=400&fit=crop",
            category: "E-commerce",
            tech_stack: "Vue.js, Python, TensorFlow, AWS",
            featured: 1,
            views: 1450,
            likes: 112
        },
        {
            title: "Ethereal Brand Identity",
            description: "Complete rebrand for luxury wellness company including logo, packaging, and digital assets",
            image_url: "https://images.unsplash.com/photo-1558655146-9f40138edfeb?w=600&h=400&fit=crop",
            category: "Branding",
            tech_stack: "Adobe Creative Suite, Figma",
            featured: 0,
            views: 750,
            likes: 45
        }
    ];

    enhancedProjects.forEach(project => {
        db.run(`INSERT OR IGNORE INTO portfolio (title, description, image_url, category, tech_stack, featured, views, likes) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)`, 
               [project.title, project.description, project.image_url, project.category, project.tech_stack, project.featured, project.views, project.likes]);
    });

    // Sample blog posts
    const samplePosts = [
        {
            title: "The Future of Web Design: Trends to Watch in 2024",
            content: "Exploring emerging design trends and technologies shaping the digital landscape...",
            excerpt: "Discover the latest trends revolutionizing web design",
            category: "Design",
            tags: "web design, trends, ui/ux",
            published: 1,
            views: 2340
        },
        {
            title: "Building Scalable Applications with Modern Architecture",
            content: "A deep dive into microservices, serverless, and cloud-native development...",
            excerpt: "Learn how to build applications that scale effortlessly",
            category: "Development",
            tags: "architecture, scalability, cloud",
            published: 1,
            views: 1870
        }
    ];

    samplePosts.forEach(post => {
        db.run(`INSERT OR IGNORE INTO blog_posts (title, content, excerpt, category, tags, published, views) 
                VALUES (?, ?, ?, ?, ?, ?, ?)`,
               [post.title, post.content, post.excerpt, post.category, post.tags, post.published, post.views]);
    });
}

// Enhanced API Routes

// Analytics tracking
app.post('/api/analytics', (req, res) => {
    const { event_type, event_data } = req.body;
    const ip_address = req.ip;
    const user_agent = req.get('User-Agent');
    
    db.run(`INSERT INTO analytics (event_type, event_data, ip_address, user_agent) VALUES (?, ?, ?, ?)`,
           [event_type, JSON.stringify(event_data), ip_address, user_agent], function(err) {
        if (err) {
            res.status(500).json({ error: 'Failed to track event' });
        } else {
            res.json({ success: true });
        }
    });
});

// Enhanced contact form with priority
app.post('/api/contact', (req, res) => {
    const { name, email, subject, message, priority = 1 } = req.body;
    
    if (!name || !email || !message) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    db.run(`INSERT INTO messages (name, email, subject, message, priority) VALUES (?, ?, ?, ?, ?)`,
           [name, email, subject || 'Website Contact', message, priority], function(err) {
        if (err) {
            res.status(500).json({ error: 'Failed to save message' });
        } else {
            // Track contact event
            db.run(`INSERT INTO analytics (event_type, event_data) VALUES (?, ?)`,
                   ['contact_form_submit', JSON.stringify({ name, email })]);
            res.json({ success: true, message: 'Message sent successfully!' });
        }
    });
});

// Enhanced newsletter with preferences
app.post('/api/newsletter', (req, res) => {
    const { email, name, preferences = 'all' } = req.body;
    
    if (!email) {
        return res.status(400).json({ error: 'Email is required' });
    }

    db.run(`INSERT OR REPLACE INTO subscribers (email, name, preferences) VALUES (?, ?, ?)`, 
           [email, name, preferences], function(err) {
        if (err) {
            res.status(500).json({ error: 'Failed to subscribe' });
        } else {
            db.run(`INSERT INTO analytics (event_type, event_data) VALUES (?, ?)`,
                   ['newsletter_signup', JSON.stringify({ email, preferences })]);
            res.json({ success: true, message: 'Successfully subscribed!' });
        }
    });
});

// Enhanced portfolio with filters and sorting
app.get('/api/portfolio', (req, res) => {
    const { featured, category, sort = 'created_at', order = 'DESC', limit = 10 } = req.query;
    
    let query = 'SELECT * FROM portfolio WHERE 1=1';
    let params = [];
    
    if (featured === 'true') {
        query += ' AND featured = 1';
    }
    
    if (category) {
        query += ' AND category = ?';
        params.push(category);
    }
    
    query += ` ORDER BY ${sort} ${order} LIMIT ?`;
    params.push(parseInt(limit));

    db.all(query, params, (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(rows);
        }
    });
});

// Portfolio item view tracking
app.post('/api/portfolio/:id/view', (req, res) => {
    const { id } = req.params;
    
    db.run('UPDATE portfolio SET views = views + 1 WHERE id = ?', [id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json({ success: true });
        }
    });
});

// Portfolio item like
app.post('/api/portfolio/:id/like', (req, res) => {
    const { id } = req.params;
    
    db.run('UPDATE portfolio SET likes = likes + 1 WHERE id = ?', [id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json({ success: true });
        }
    });
});

// Blog posts API
app.get('/api/blog', (req, res) => {
    const { category, limit = 5 } = req.query;
    
    let query = 'SELECT * FROM blog_posts WHERE published = 1';
    let params = [];
    
    if (category) {
        query += ' AND category = ?';
        params.push(category);
    }
    
    query += ' ORDER BY created_at DESC LIMIT ?';
    params.push(parseInt(limit));

    db.all(query, params, (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(rows);
        }
    });
});

// Dashboard stats (admin)
app.get('/api/stats', (req, res) => {
    const stats = {};
    
    // Get total messages
    db.get('SELECT COUNT(*) as total FROM messages', (err, result) => {
        if (!err) stats.totalMessages = result.total;
        
        // Get total subscribers
        db.get('SELECT COUNT(*) as total FROM subscribers WHERE active = 1', (err, result) => {
            if (!err) stats.totalSubscribers = result.total;
            
            // Get total portfolio views
            db.get('SELECT SUM(views) as total FROM portfolio', (err, result) => {
                if (!err) stats.totalViews = result.total || 0;
                
                // Get recent analytics
                db.all('SELECT event_type, COUNT(*) as count FROM analytics WHERE created_at > datetime("now", "-7 days") GROUP BY event_type', (err, result) => {
                    if (!err) stats.weeklyEvents = result;
                    
                    res.json(stats);
                });
            });
        });
    });
});

// Get messages with status filter
app.get('/api/messages', (req, res) => {
    const { status = 'all' } = req.query;
    
    let query = 'SELECT * FROM messages';
    let params = [];
    
    if (status !== 'all') {
        query += ' WHERE status = ?';
        params.push(status);
    }
    
    query += ' ORDER BY priority DESC, created_at DESC';

    db.all(query, params, (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(rows);
        }
    });
});

// Update message status
app.put('/api/messages/:id', (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    
    db.run('UPDATE messages SET status = ? WHERE id = ?', [status, id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json({ success: true });
        }
    });
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
    console.log(`🌟 Aesthetic Website V3 running on http://localhost:${PORT}`);
    console.log(`🎨 Theme: Emerald Sunset`);
    console.log(`✨ Enhanced features activated`);
});
// ===== AESTHETIC WEBSITE V3 - EMERALD SUNSET EDITION SCRIPT =====

class AestheticWebsiteV3 {
    constructor() {
        this.navbar = document.getElementById('navbar');
        this.hamburger = document.getElementById('hamburger');
        this.navMenu = document.getElementById('nav-menu');
        this.contactForm = document.getElementById('contactForm');
        this.newsletterForm = document.getElementById('newsletterForm');
        this.portfolioGrid = document.getElementById('portfolioGrid');
        this.blogGrid = document.getElementById('blogGrid');
        this.statsGrid = document.getElementById('statsGrid');
        this.themeToggle = document.getElementById('themeToggle');
        
        // Animation and interaction states
        this.isScrolling = false;
        this.currentTheme = localStorage.getItem('theme') || 'light';
        this.portfolioData = [];
        this.blogData = [];
        this.statsData = {};
        
        this.init();
    }
    
    init() {
        this.initializeTheme();
        this.bindEvents();
        this.initializeAnimations();
        this.initializeParticles();
        this.initializeCursor();
        this.loadPortfolio();
        this.loadBlog();
        this.loadStats();
        this.initializeScrollAnimations();
        this.initializeCounters();
        this.trackAnalytics('page_view', { page: 'home' });
    }
    
    // Theme Management
    initializeTheme() {
        document.documentElement.setAttribute('data-theme', this.currentTheme);
        this.updateThemeIcon();
    }
    
    toggleTheme() {
        this.currentTheme = this.currentTheme === 'light' ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', this.currentTheme);
        localStorage.setItem('theme', this.currentTheme);
        this.updateThemeIcon();
        this.trackAnalytics('theme_toggle', { theme: this.currentTheme });
    }
    
    updateThemeIcon() {
        const icon = this.themeToggle.querySelector('i');
        if (this.currentTheme === 'dark') {
            icon.className = 'fas fa-sun';
        } else {
            icon.className = 'fas fa-moon';
        }
    }
    
    // Event Binding
    bindEvents() {
        // Scroll events
        window.addEventListener('scroll', () => this.handleScroll(), { passive: true });
        
        // Navigation events
        this.hamburger.addEventListener('click', () => this.toggleMobileMenu());
        this.themeToggle.addEventListener('click', () => this.toggleTheme());
        
        // Smooth scroll for navigation links
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => this.handleNavClick(e));
        });
        
        // Form events
        this.contactForm.addEventListener('submit', (e) => this.handleContactForm(e));
        this.newsletterForm.addEventListener('submit', (e) => this.handleNewsletterForm(e));
        
        // Portfolio filter events
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.addEventListener('click', (e) => this.handlePortfolioFilter(e));
        });
        
        // Window resize events
        window.addEventListener('resize', () => this.handleResize());
        
        // Mouse move for cursor
        document.addEventListener('mousemove', (e) => this.updateCursor(e));
        
        // Keyboard navigation
        document.addEventListener('keydown', (e) => this.handleKeyNavigation(e));
        
        // Close mobile menu on outside click
        document.addEventListener('click', (e) => {
            if (!this.navMenu.contains(e.target) && !this.hamburger.contains(e.target)) {
                this.closeMobileMenu();
            }
        });
    }
    
    // Scroll Handler
    handleScroll() {
        if (!this.isScrolling) {
            window.requestAnimationFrame(() => {
                this.updateNavbar();
                this.updateActiveNavLink();
                this.updateParallax();
                this.isScrolling = false;
            });
            this.isScrolling = true;
        }
    }
    
    updateNavbar() {
        const scrollY = window.scrollY;
        if (scrollY > 100) {
            this.navbar.classList.add('scrolled');
        } else {
            this.navbar.classList.remove('scrolled');
        }
    }
    
    updateActiveNavLink() {
        const sections = document.querySelectorAll('section[id]');
        const navLinks = document.querySelectorAll('.nav-link');
        
        let current = '';
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 200;
            if (window.scrollY >= sectionTop) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${current}`) {
                link.classList.add('active');
            }
        });
    }
    
    updateParallax() {
        const scrollY = window.scrollY;
        const meshGradients = document.querySelectorAll('.mesh-gradient');
        
        meshGradients.forEach((gradient, index) => {
            const speed = 0.3 + (index * 0.1);
            const yPos = -(scrollY * speed);
            gradient.style.transform = `translateY(${yPos}px)`;
        });
    }
    
    // Navigation Handlers
    handleNavClick(e) {
        e.preventDefault();
        const targetId = e.target.getAttribute('href');
        const targetSection = document.querySelector(targetId);
        
        if (targetSection) {
            this.smoothScrollTo(targetSection);
            this.closeMobileMenu();
            this.trackAnalytics('navigation_click', { section: targetId });
        }
    }
    
    smoothScrollTo(element) {
        const offsetTop = element.offsetTop - 80;
        window.scrollTo({
            top: offsetTop,
            behavior: 'smooth'
        });
    }
    
    toggleMobileMenu() {
        this.hamburger.classList.toggle('active');
        this.navMenu.classList.toggle('active');
        document.body.style.overflow = this.navMenu.classList.contains('active') ? 'hidden' : '';
        
        // Animate menu items
        if (this.navMenu.classList.contains('active')) {
            this.animateMenuItems();
        }
    }
    
    closeMobileMenu() {
        this.hamburger.classList.remove('active');
        this.navMenu.classList.remove('active');
        document.body.style.overflow = '';
    }
    
    animateMenuItems() {
        const menuItems = this.navMenu.querySelectorAll('.nav-link');
        menuItems.forEach((item, index) => {
            item.style.opacity = '0';
            item.style.transform = 'translateY(20px)';
            setTimeout(() => {
                item.style.transition = 'all 0.3s ease';
                item.style.opacity = '1';
                item.style.transform = 'translateY(0)';
            }, index * 100);
        });
    }
    
    // Keyboard Navigation
    handleKeyNavigation(e) {
        if (e.key === 'Escape') {
            this.closeMobileMenu();
        }
        
        // Navigate sections with arrow keys
        if (e.key === 'ArrowDown' && e.ctrlKey) {
            e.preventDefault();
            this.navigateToNextSection();
        }
        
        if (e.key === 'ArrowUp' && e.ctrlKey) {
            e.preventDefault();
            this.navigateToPrevSection();
        }
    }
    
    navigateToNextSection() {
        const sections = Array.from(document.querySelectorAll('section[id]'));
        const currentIndex = sections.findIndex(section => {
            const rect = section.getBoundingClientRect();
            return rect.top >= 0;
        });
        
        if (currentIndex < sections.length - 1) {
            this.smoothScrollTo(sections[currentIndex + 1]);
        }
    }
    
    navigateToPrevSection() {
        const sections = Array.from(document.querySelectorAll('section[id]'));
        const currentIndex = sections.findIndex(section => {
            const rect = section.getBoundingClientRect();
            return rect.top >= 0;
        });
        
        if (currentIndex > 0) {
            this.smoothScrollTo(sections[currentIndex - 1]);
        }
    }
    
    // Cursor Management
    initializeCursor() {
        this.cursor = document.querySelector('.cursor-follower');
        if (!this.cursor) return;
        
        // Hide cursor initially
        this.cursor.style.opacity = '0';
    }
    
    updateCursor(e) {
        if (!this.cursor) return;
        
        const x = e.clientX;
        const y = e.clientY;
        
        this.cursor.style.left = x + 'px';
        this.cursor.style.top = y + 'px';
        this.cursor.style.opacity = '0.6';
        
        // Add hover effects for interactive elements
        const interactive = e.target.closest('a, button, .portfolio-item, .service-card');
        if (interactive) {
            this.cursor.style.transform = 'translate(-50%, -50%) scale(1.5)';
            this.cursor.style.opacity = '0.8';
        } else {
            this.cursor.style.transform = 'translate(-50%, -50%) scale(1)';
            this.cursor.style.opacity = '0.6';
        }
    }
    
    // Particle System
    initializeParticles() {
        const canvas = document.getElementById('particleCanvas');
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        const particles = [];
        const particleCount = 50;
        
        // Set canvas size
        const resizeCanvas = () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        };
        
        resizeCanvas();
        window.addEventListener('resize', resizeCanvas);
        
        // Particle class
        class Particle {
            constructor() {
                this.x = Math.random() * canvas.width;
                this.y = Math.random() * canvas.height;
                this.vx = (Math.random() - 0.5) * 0.5;
                this.vy = (Math.random() - 0.5) * 0.5;
                this.size = Math.random() * 2 + 1;
                this.opacity = Math.random() * 0.5 + 0.2;
            }
            
            update() {
                this.x += this.vx;
                this.y += this.vy;
                
                if (this.x < 0 || this.x > canvas.width) this.vx *= -1;
                if (this.y < 0 || this.y > canvas.height) this.vy *= -1;
            }
            
            draw() {
                ctx.beginPath();
                ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
                ctx.fillStyle = `rgba(255, 255, 255, ${this.opacity})`;
                ctx.fill();
            }
        }
        
        // Create particles
        for (let i = 0; i < particleCount; i++) {
            particles.push(new Particle());
        }
        
        // Animation loop
        const animate = () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            particles.forEach(particle => {
                particle.update();
                particle.draw();
            });
            
            // Draw connections
            particles.forEach((particle, i) => {
                particles.slice(i + 1).forEach(otherParticle => {
                    const distance = Math.hypot(
                        particle.x - otherParticle.x,
                        particle.y - otherParticle.y
                    );
                    
                    if (distance < 100) {
                        ctx.beginPath();
                        ctx.moveTo(particle.x, particle.y);
                        ctx.lineTo(otherParticle.x, otherParticle.y);
                        ctx.strokeStyle = `rgba(255, 255, 255, ${0.1 * (1 - distance / 100)})`;
                        ctx.lineWidth = 0.5;
                        ctx.stroke();
                    }
                });
            });
            
            requestAnimationFrame(animate);
        };
        
        animate();
    }
    
    // Portfolio Management
    async loadPortfolio() {
        try {
            const response = await fetch('/api/portfolio?featured=true&limit=6');
            this.portfolioData = await response.json();
            this.renderPortfolio(this.portfolioData);
        } catch (error) {
            console.error('Error loading portfolio:', error);
            this.renderPortfolioFallback();
        }
    }
    
    renderPortfolio(items) {
        if (!this.portfolioGrid) return;
        
        this.portfolioGrid.innerHTML = items.map(item => `
            <div class="portfolio-item" data-category="${item.category}" data-aos="fade-up">
                <div class="portfolio-image" style="background-image: url('${item.image_url}')">
                    <div class="portfolio-overlay">
                        <span>View Project</span>
                    </div>
                </div>
                <div class="portfolio-content">
                    <div class="portfolio-category">${item.category}</div>
                    <h3>${item.title}</h3>
                    <p>${item.description}</p>
                    <div class="portfolio-stats">
                        <span class="stat">
                            <i class="fas fa-eye"></i>
                            ${this.formatNumber(item.views || 0)}
                        </span>
                        <span class="stat">
                            <i class="fas fa-heart"></i>
                            ${this.formatNumber(item.likes || 0)}
                        </span>
                    </div>
                </div>
            </div>
        `).join('');
        
        // Add click handlers for portfolio items
        this.portfolioGrid.querySelectorAll('.portfolio-item').forEach((item, index) => {
            item.addEventListener('click', () => {
                this.openPortfolioModal(this.portfolioData[index]);
                this.trackPortfolioView(this.portfolioData[index].id);
            });
        });
    }
    
    renderPortfolioFallback() {
        if (!this.portfolioGrid) return;
        
        const fallbackItems = [
            {
                title: "NeoSync Dashboard",
                description: "Advanced analytics platform with real-time data visualization",
                category: "Web Application",
                image_url: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=600&h=400&fit=crop",
                views: 1250,
                likes: 89
            },
            {
                title: "Aurora Mobile Suite", 
                description: "Cross-platform mobile application with biometric authentication",
                category: "Mobile App",
                image_url: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?w=600&h=400&fit=crop",
                views: 980,
                likes: 67
            },
            {
                title: "Quantum E-commerce",
                description: "Next-generation shopping platform with AR try-on features",
                category: "E-commerce", 
                image_url: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&h=400&fit=crop",
                views: 1450,
                likes: 112
            }
        ];
        
        this.renderPortfolio(fallbackItems);
    }
    
    handlePortfolioFilter(e) {
        const filter = e.target.dataset.filter;
        const filterBtns = document.querySelectorAll('.filter-btn');
        const portfolioItems = document.querySelectorAll('.portfolio-item');
        
        // Update active filter button
        filterBtns.forEach(btn => btn.classList.remove('active'));
        e.target.classList.add('active');
        
        // Filter portfolio items
        portfolioItems.forEach(item => {
            const category = item.dataset.category;
            if (filter === 'all' || category === filter) {
                item.style.display = 'block';
                item.style.animation = 'fadeInUp 0.6s ease';
            } else {
                item.style.display = 'none';
            }
        });
        
        this.trackAnalytics('portfolio_filter', { filter });
    }
    
    async trackPortfolioView(portfolioId) {
        try {
            await fetch(`/api/portfolio/${portfolioId}/view`, {
                method: 'POST'
            });
        } catch (error) {
            console.error('Error tracking portfolio view:', error);
        }
    }
    
    // Blog Management
    async loadBlog() {
        try {
            const response = await fetch('/api/blog?limit=3');
            this.blogData = await response.json();
            this.renderBlog(this.blogData);
        } catch (error) {
            console.error('Error loading blog:', error);
            this.renderBlogFallback();
        }
    }
    
    renderBlog(posts) {
        if (!this.blogGrid) return;
        
        this.blogGrid.innerHTML = posts.map(post => `
            <article class="blog-card" data-aos="fade-up">
                <div class="blog-image" style="background-image: url('${post.image_url || 'https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=600&h=400&fit=crop'}')"></div>
                <div class="blog-content">
                    <div class="blog-meta">
                        <span class="blog-category">${post.category}</span>
                        <span class="blog-date">${this.formatDate(post.created_at)}</span>
                    </div>
                    <h3>${post.title}</h3>
                    <p class="blog-excerpt">${post.excerpt}</p>
                    <div class="blog-stats">
                        <span class="stat">
                            <i class="fas fa-eye"></i>
                            ${this.formatNumber(post.views || 0)} views
                        </span>
                        <span class="stat">
                            <i class="fas fa-clock"></i>
                            ${this.calculateReadTime(post.content)} min read
                        </span>
                    </div>
                </div>
            </article>
        `).join('');
    }
    
    renderBlogFallback() {
        if (!this.blogGrid) return;
        
        const fallbackPosts = [
            {
                title: "The Future of Web Design: Trends to Watch in 2024",
                excerpt: "Discover the latest trends revolutionizing web design and user experience",
                category: "Design",
                created_at: new Date().toISOString(),
                views: 2340,
                content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit..."
            },
            {
                title: "Building Scalable Applications with Modern Architecture", 
                excerpt: "Learn how to build applications that scale effortlessly with cloud-native patterns",
                category: "Development",
                created_at: new Date(Date.now() - 86400000).toISOString(),
                views: 1870,
                content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit..."
            }
        ];
        
        this.renderBlog(fallbackPosts);
    }
    
    // Stats Management
    async loadStats() {
        try {
            const response = await fetch('/api/stats');
            this.statsData = await response.json();
            this.renderStats(this.statsData);
        } catch (error) {
            console.error('Error loading stats:', error);
            this.renderStatsFallback();
        }
    }
    
    renderStats(stats) {
        if (!this.statsGrid) return;
        
        const statsItems = [
            {
                icon: 'fas fa-envelope',
                value: stats.totalMessages || 0,
                label: 'Messages Received',
                description: 'Client inquiries this month'
            },
            {
                icon: 'fas fa-users',
                value: stats.totalSubscribers || 0,
                label: 'Newsletter Subscribers', 
                description: 'Active subscribers'
            },
            {
                icon: 'fas fa-eye',
                value: stats.totalViews || 0,
                label: 'Portfolio Views',
                description: 'Total project views'
            },
            {
                icon: 'fas fa-chart-line',
                value: stats.weeklyEvents?.length || 0,
                label: 'Weekly Events',
                description: 'Analytics events this week'
            }
        ];
        
        this.statsGrid.innerHTML = statsItems.map(stat => `
            <div class="stat-card" data-aos="fade-up">
                <div class="stat-icon">
                    <i class="${stat.icon}"></i>
                </div>
                <div class="stat-value" data-count="${stat.value}">0</div>
                <div class="stat-label">${stat.label}</div>
                <div class="stat-description">${stat.description}</div>
            </div>
        `).join('');
        
        // Animate counters
        this.animateCounters();
    }
    
    renderStatsFallback() {
        if (!this.statsGrid) return;
        
        const fallbackStats = {
            totalMessages: 150,
            totalSubscribers: 1200,
            totalViews: 25000,
            weeklyEvents: new Array(25)
        };
        
        this.renderStats(fallbackStats);
    }
    
    // Form Handlers
    async handleContactForm(e) {
        e.preventDefault();
        
        const formData = new FormData(this.contactForm);
        const data = Object.fromEntries(formData.entries());
        
        const submitButton = this.contactForm.querySelector('.submit-button-v3');
        const originalContent = submitButton.innerHTML;
        
        // Show loading state
        this.setButtonLoading(submitButton, 'Sending Message...');
        
        try {
            const response = await fetch('/api/contact', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            
            const result = await response.json();
            
            if (response.ok) {
                this.showNotification('Message sent successfully! We\'ll get back to you soon.', 'success');
                this.contactForm.reset();
                this.trackAnalytics('contact_form_submit', data);
            } else {
                this.showNotification(result.error || 'Failed to send message. Please try again.', 'error');
            }
            
        } catch (error) {
            console.error('Contact form error:', error);
            this.showNotification('Network error. Please check your connection and try again.', 'error');
        } finally {
            this.resetButton(submitButton, originalContent);
        }
    }
    
    async handleNewsletterForm(e) {
        e.preventDefault();
        
        const formData = new FormData(this.newsletterForm);
        const data = Object.fromEntries(formData.entries());
        
        const submitButton = this.newsletterForm.querySelector('button');
        const originalContent = submitButton.innerHTML;
        
        this.setButtonLoading(submitButton, 'Subscribing...');
        
        try {
            const response = await fetch('/api/newsletter', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            
            const result = await response.json();
            
            if (response.ok) {
                this.showNotification('Successfully subscribed to our newsletter!', 'success');
                this.newsletterForm.reset();
                this.trackAnalytics('newsletter_signup', data);
            } else {
                this.showNotification(result.error || 'Subscription failed. Please try again.', 'error');
            }
            
        } catch (error) {
            console.error('Newsletter form error:', error);
            this.showNotification('Network error. Please try again.', 'error');
        } finally {
            this.resetButton(submitButton, originalContent);
        }
    }
    
    setButtonLoading(button, text) {
        button.disabled = true;
        button.innerHTML = `<i class="fas fa-spinner fa-spin"></i> ${text}`;
        button.style.opacity = '0.7';
    }
    
    resetButton(button, originalContent) {
        button.disabled = false;
        button.innerHTML = originalContent;
        button.style.opacity = '1';
    }
    
    // Notification System
    showNotification(message, type = 'info', duration = 5000) {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <div class="notification-content">
                <i class="fas fa-${this.getNotificationIcon(type)}"></i>
                <span>${message}</span>
            </div>
            <button class="notification-close" aria-label="Close notification">×</button>
        `;
        
        // Enhanced styles
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            background: ${this.getNotificationColor(type)};
            color: white;
            padding: 16px 20px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
            z-index: 10000;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 15px;
            max-width: 400px;
            min-width: 300px;
            animation: slideInRight 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.1);
        `;
        
        document.body.appendChild(notification);
        
        // Close button functionality
        const closeBtn = notification.querySelector('.notification-close');
        closeBtn.style.cssText = `
            background: none;
            border: none;
            color: white;
            font-size: 18px;
            cursor: pointer;
            padding: 0;
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: background-color 0.2s;
        `;
        
        closeBtn.addEventListener('click', () => this.removeNotification(notification));
        closeBtn.addEventListener('mouseenter', () => {
            closeBtn.style.backgroundColor = 'rgba(255,255,255,0.2)';
        });
        closeBtn.addEventListener('mouseleave', () => {
            closeBtn.style.backgroundColor = 'transparent';
        });
        
        // Auto remove
        setTimeout(() => {
            if (notification.parentNode) {
                this.removeNotification(notification);
            }
        }, duration);
        
        // Stack multiple notifications
        this.stackNotifications();
    }
    
    removeNotification(notification) {
        notification.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.remove();
                this.stackNotifications();
            }
        }, 300);
    }
    
    stackNotifications() {
        const notifications = document.querySelectorAll('.notification');
        notifications.forEach((notification, index) => {
            notification.style.top = `${100 + (index * 80)}px`;
        });
    }
    
    getNotificationIcon(type) {
        const icons = {
            success: 'check-circle',
            error: 'exclamation-circle',
            warning: 'exclamation-triangle',
            info: 'info-circle'
        };
        return icons[type] || icons.info;
    }
    
    getNotificationColor(type) {
        const colors = {
            success: 'linear-gradient(135deg, #10b981, #059669)',
            error: 'linear-gradient(135deg, #ef4444, #dc2626)', 
            warning: 'linear-gradient(135deg, #f59e0b, #d97706)',
            info: 'linear-gradient(135deg, #3b82f6, #2563eb)'
        };
        return colors[type] || colors.info;
    }
    
    // Animation Systems
    initializeAnimations() {
        // Add CSS animations dynamically
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideInRight {
                from {
                    opacity: 0;
                    transform: translateX(100%);
                }
                to {
                    opacity: 1;
                    transform: translateX(0);
                }
            }
            
            @keyframes slideOutRight {
                from {
                    opacity: 1;
                    transform: translateX(0);
                }
                to {
                    opacity: 0;
                    transform: translateX(100%);
                }
            }
            
            @keyframes fadeInUp {
                from {
                    opacity: 0;
                    transform: translateY(30px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            @keyframes countUp {
                from { opacity: 0; transform: translateY(20px); }
                to { opacity: 1; transform: translateY(0); }
            }
            
            .notification-content {
                display: flex;
                align-items: center;
                gap: 12px;
                font-weight: 500;
            }
            
            .portfolio-stats, .blog-stats {
                display: flex;
                gap: 15px;
                margin-top: 12px;
                font-size: 0.9rem;
                color: #64748b;
            }
            
            .stat {
                display: flex;
                align-items: center;
                gap: 4px;
            }
        `;
        document.head.appendChild(style);
    }
    
    initializeScrollAnimations() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                    
                    // Trigger counter animation for stat cards 
                    if (entry.target.classList.contains('stat-card')) {
                        this.animateCounter(entry.target);
                    }
                }
            });
        }, observerOptions);
        
        // Observe elements for animation
        const animatedElements = document.querySelectorAll(`
            .about-card, .service-card, .portfolio-item, 
            .blog-card, .stat-card, .contact-item
        `);
        
        animatedElements.forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(30px)';
            el.style.transition = 'all 0.6s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
            observer.observe(el);
        });
    }
    
    initializeCounters() {
        // Counter for hero stats
        const heroCounters = document.querySelectorAll('#projectsCount');
        heroCounters.forEach(counter => {
            this.animateNumber(counter, 0, 150, 2000);
        });
    }
    
    animateCounters() {
        const statCards = document.querySelectorAll('.stat-card');
        statCards.forEach(card => {
            setTimeout(() => this.animateCounter(card), Math.random() * 1000);
        });
    }
    
    animateCounter(card) {
        const valueElement = card.querySelector('.stat-value');
        if (!valueElement || valueElement.dataset.animated) return;
        
        const target = parseInt(valueElement.dataset.count) || 0;
        this.animateNumber(valueElement, 0, target, 2000);
        valueElement.dataset.animated = 'true';
    }
    
    animateNumber(element, start, end, duration) {
        const startTime = performance.now();
        const updateNumber = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            // Easing function for smooth animation
            const easeOutQuart = 1 - Math.pow(1 - progress, 4);
            const current = Math.floor(start + (end - start) * easeOutQuart);
            
            element.textContent = this.formatNumber(current);
            
            if (progress < 1) {
                requestAnimationFrame(updateNumber);
            } else {
                element.textContent = this.formatNumber(end);
            }
        };
        
        requestAnimationFrame(updateNumber);
    }
    
    // Portfolio Modal System
    openPortfolioModal(item) {
        const modal = this.createPortfolioModal(item);
        document.body.appendChild(modal);
        document.body.style.overflow = 'hidden';
        
        // Animate modal in
        setTimeout(() => {
            modal.classList.add('active');
        }, 10);
        
        // Close handlers
        const closeModal = () => this.closePortfolioModal(modal);
        modal.querySelector('.modal-close').addEventListener('click', closeModal);
        modal.querySelector('.modal-overlay').addEventListener('click', closeModal);
        
        // Keyboard close
        const handleKeyDown = (e) => {
            if (e.key === 'Escape') {
                closeModal();
                document.removeEventListener('keydown', handleKeyDown);
            }
        };
        document.addEventListener('keydown', handleKeyDown);
    }
    
    createPortfolioModal(item) {
        const modal = document.createElement('div');
        modal.className = 'portfolio-modal';
        modal.innerHTML = `
            <div class="modal-overlay"></div>
            <div class="modal-content">
                <button class="modal-close" aria-label="Close modal">
                    <i class="fas fa-times"></i>
                </button>
                <div class="modal-image">
                    <img src="${item.image_url}" alt="${item.title}" loading="lazy">
                </div>
                <div class="modal-info">
                    <div class="modal-category">${item.category}</div>
                    <h2 class="modal-title">${item.title}</h2>
                    <p class="modal-description">${item.description}</p>
                    ${item.tech_stack ? `
                        <div class="modal-tech">
                            <h4>Technologies Used:</h4>
                            <div class="tech-tags">
                                ${item.tech_stack.split(',').map(tech => 
                                    `<span class="tech-tag">${tech.trim()}</span>`
                                ).join('')}
                            </div>
                        </div>
                    ` : ''}
                    <div class="modal-stats">
                        <div class="stat">
                            <i class="fas fa-eye"></i>
                            <span>${this.formatNumber(item.views || 0)} views</span>
                        </div>
                        <div class="stat">
                            <i class="fas fa-heart"></i>
                            <span>${this.formatNumber(item.likes || 0)} likes</span>
                        </div>
                    </div>
                    <div class="modal-actions">
                        ${item.project_url ? `
                            <a href="${item.project_url}" target="_blank" class="modal-btn primary">
                                <i class="fas fa-external-link-alt"></i>
                                View Live Project
                            </a>
                        ` : ''}
                        ${item.github_url ? `
                            <a href="${item.github_url}" target="_blank" class="modal-btn secondary">
                                <i class="fab fa-github"></i>
                                View Code
                            </a>
                        ` : ''}
                        <button class="modal-btn tertiary" onclick="this.closest('.portfolio-modal').querySelector('.modal-close').click()">
                            <i class="fas fa-arrow-left"></i>
                            Back to Portfolio
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        // Add modal styles
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 10000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        `;
        
        return modal;
    }
    
    closePortfolioModal(modal) {
        modal.classList.remove('active');
        setTimeout(() => {
            document.body.removeChild(modal);
            document.body.style.overflow = '';
        }, 300);
    }
    
    // Analytics Tracking
    async trackAnalytics(eventType, eventData = {}) {
        try {
            await fetch('/api/analytics', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    event_type: eventType,
                    event_data: eventData
                })
            });
        } catch (error) {
            console.error('Analytics tracking error:', error);
        }
    }
    
    // Utility Functions
    formatNumber(num) {
        if (num >= 1000000) {
            return (num / 1000000).toFixed(1) + 'M';
        } else if (num >= 1000) {
            return (num / 1000).toFixed(1) + 'K';
        }
        return num.toString();
    }
    
    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }
    
    calculateReadTime(content) {
        const wordsPerMinute = 200;
        const wordCount = content.split(' ').length;
        return Math.ceil(wordCount / wordsPerMinute);
    }
    
    // Resize Handler
    handleResize() {
        // Recalculate particle canvas size
        const canvas = document.getElementById('particleCanvas');
        if (canvas) {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        }
        
        // Close mobile menu on resize to desktop
        if (window.innerWidth > 768) {
            this.closeMobileMenu();
        }
        
        // Restack notifications
        this.stackNotifications();
    }
    
    // Performance Monitoring
    initializePerformanceMonitoring() {
        // Monitor page load performance
        window.addEventListener('load', () => {
            setTimeout(() => {
                const perfData = performance.getEntriesByType('navigation')[0];
                this.trackAnalytics('page_performance', {
                    loadTime: perfData.loadEventEnd - perfData.loadEventStart,
                    domContentLoaded: perfData.domContentLoadedEventEnd - perfData.domContentLoadedEventStart,
                    firstPaint: performance.getEntriesByType('paint')[0]?.startTime || 0
                });
            }, 1000);
        });
        
        // Monitor scroll performance
        let scrollCount = 0;
        window.addEventListener('scroll', () => {
            scrollCount++;
            if (scrollCount % 50 === 0) {
                this.trackAnalytics('scroll_interaction', {
                    scrollDepth: Math.round((window.scrollY / document.body.scrollHeight) * 100)
                });
            }
        }, { passive: true });
    }
    
    // Error Handling
    initializeErrorHandling() {
        window.addEventListener('error', (e) => {
            console.error('JavaScript Error:', e);
            this.trackAnalytics('javascript_error', {
                message: e.message,
                filename: e.filename,
                lineNumber: e.lineno
            });
        });
        
        window.addEventListener('unhandledrejection', (e) => {
            console.error('Unhandled Promise Rejection:', e);
            this.trackAnalytics('promise_rejection', {
                reason: e.reason?.toString() || 'Unknown'
            });
        });
    }
    
    // Accessibility Enhancements
    initializeAccessibility() {
        // Skip link for keyboard users
        const skipLink = document.createElement('a');
        skipLink.href = '#main';
        skipLink.textContent = 'Skip to main content';
        skipLink.className = 'skip-link';
        skipLink.style.cssText = `
            position: absolute;
            top: -100px;
            left: 20px;
            background: var(--emerald-primary);
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 5px;
            z-index: 10001;
            transition: top 0.3s;
        `;
        
        skipLink.addEventListener('focus', () => {
            skipLink.style.top = '20px';
        });
        
        skipLink.addEventListener('blur', () => {
            skipLink.style.top = '-100px';
        });
        
        document.body.insertBefore(skipLink, document.body.firstChild);
        
        // Announce route changes for screen readers
        this.announceRouteChanges();
        
        // Enhanced focus management
        this.manageFocus();
    }
    
    announceRouteChanges() {
        const announcer = document.createElement('div');
        announcer.setAttribute('aria-live', 'polite');
        announcer.setAttribute('aria-atomic', 'true');
        announcer.style.cssText = `
            position: absolute;
            left: -10000px;
            width: 1px;
            height: 1px;
            overflow: hidden;
        `;
        document.body.appendChild(announcer);
        
        // Announce section changes
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting && entry.intersectionRatio > 0.5) {
                    const sectionName = entry.target.id || 'Section';
                    announcer.textContent = `Now viewing ${sectionName} section`;
                }
            });
        }, { threshold: 0.5 });
        
        document.querySelectorAll('section[id]').forEach(section => {
            observer.observe(section);
        });
    }
    
    manageFocus() {
        // Trap focus in modal
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Tab') {
                const modal = document.querySelector('.portfolio-modal.active');
                if (modal) {
                    this.trapFocus(e, modal);
                }
            }
        });
    }
    
    trapFocus(e, container) {
        const focusableElements = container.querySelectorAll(
            'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        
        const firstFocusable = focusableElements[0];
        const lastFocusable = focusableElements[focusableElements.length - 1];
        
        if (e.shiftKey) {
            if (document.activeElement === firstFocusable) {
                lastFocusable.focus();
                e.preventDefault();
            }
        } else {
            if (document.activeElement === lastFocusable) {
                firstFocusable.focus();
                e.preventDefault();
            }
        }
    }
    
    // Initialize everything
    initializeAll() {
        this.initializePerformanceMonitoring();
        this.initializeErrorHandling();
        this.initializeAccessibility();
    }
}

// Enhanced utility functions
function scrollToSection(sectionId) {
    const section = document.getElementById(sectionId);
    if (section) {
        const offsetTop = section.offsetTop - 80;
        window.scrollTo({
            top: offsetTop,
            behavior: 'smooth'
        });
        
        // Track navigation
        if (window.aesthetic) {
            window.aesthetic.trackAnalytics('scroll_to_section', { section: sectionId });
        }
    }
}

// Lazy loading images
function initializeLazyLoading() {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                observer.unobserve(img);
            }
        });
    });
    
    document.querySelectorAll('img[data-src]').forEach(img => {
        imageObserver.observe(img);
    });
}

// Service Worker registration for PWA capabilities
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => {
                console.log('SW registered: ', registration);
            })
            .catch(registrationError => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}

// Enhanced modal styles (added dynamically)
function addModalStyles() {
    const modalStyles = document.createElement('style');
    modalStyles.textContent = `
        .portfolio-modal {
            backdrop-filter: blur(10px);
        }
        
        .portfolio-modal.active {
            opacity: 1;
            visibility: visible;
        }
        
        .modal-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.8);
        }
        
        .modal-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            border-radius: 20px;
            max-width: 90%;
            max-height: 90%;
            width: 800px;
            overflow-y: auto;
            animation: modalSlideIn 0.3s ease;
        }
        
        .modal-close {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            color: white;
            cursor: pointer;
            z-index: 10;
            transition: all 0.3s ease;
        }
        
        .modal-close:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: scale(1.1);
        }
        
        .modal-image {
            width: 100%;
            height: 300px;
            overflow: hidden;
            border-radius: 20px 20px 0 0;
        }
        
        .modal-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .modal-info {
            padding: 30px;
        }
        
        .modal-category {
            color: var(--emerald-primary);
            font-weight: 600;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 10px;
        }
        
        .modal-title {
            font-size: 2rem;
            font-weight: 800;
            margin-bottom: 15px;
            color: var(--text-primary);
        }
        
        .modal-description {
            color: var(--text-secondary);
            line-height: 1.7;
            margin-bottom: 25px;
        }
        
        .modal-tech {
            margin-bottom: 25px;
        }
        
        .modal-tech h4 {
            margin-bottom: 10px;
            color: var(--text-primary);
        }
        
        .tech-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }
        
        .tech-tag {
            background: var(--bg-secondary);
            color: var(--text-secondary);
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }
        
        .modal-stats {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            padding: 20px;
            background: var(--bg-secondary);
            border-radius: 12px;
        }
        
        .modal-stats .stat {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--text-secondary);
        }
        
        .modal-actions {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }
        
        .modal-btn {
            padding: 12px 24px;
            border-radius: 25px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            border: none;
            cursor: pointer;
        }
        
        .modal-btn.primary {
            background: var(--gradient-emerald);
            color: white;
        }
        
        .modal-btn.secondary {
            background: var(--gradient-sunset);
            color: white;
        }
        
        .modal-btn.tertiary {
            background: var(--bg-secondary);
            color: var(--text-primary);
        }
        
        .modal-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        @keyframes modalSlideIn {
            from {
                opacity: 0;
                transform: translate(-50%, -50%) scale(0.9);
            }
            to {
                opacity: 1;
                transform: translate(-50%, -50%) scale(1);
            }
        }
        
        @media (max-width: 768px) {
            .modal-content {
                width: 95%;
                margin: 20px;
            }
            
            .modal-actions {
                flex-direction: column;
            }
            
            .modal-btn {
                justify-content: center;
            }
        }
    `;
    document.head.appendChild(modalStyles);
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Add modal styles
    addModalStyles();
    
    // Initialize lazy loading
    initializeLazyLoading();
    
    // Initialize the main website class
    window.aesthetic = new AestheticWebsiteV3();
    window.aesthetic.initializeAll();
    
    // Global scroll to section function
    window.scrollToSection = scrollToSection;
    
    console.log('🌟 Aesthetic Website V3 - Emerald Sunset Edition initialized');
    console.log('✨ All enhanced features activated');
});

// Export for module use if needed
if (typeof module !== 'undefined' && module.exports) {
    module.exports = AestheticWebsiteV3;
}